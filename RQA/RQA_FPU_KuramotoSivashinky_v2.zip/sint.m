t=linspace(1,5,1000)';
plot(sin(2*pi()*t));
data=sin(2*pi()*t);
plot(data)
%% 
rqa_data=crqa(data, 1, 1, .2, 100, 1, 'euc', 'silent');

%%
%If RQA data is available, just run this cell alone.
[s1,s2] = size(data);
[s3,s4] = size(rqa_data(:,6));
padding_array=zeros(s1-s3,1);
i_lam = vertcat(padding_array, rqa_data(:,6));

subplot(2,2,1);
plot(data, 'k -');
axis([0 s1 ymin ymax])
title('Normalized data')
xlabel('Time instance', 'fontsize', 14)
xt = get(gca, 'XTick');
set(gca, 'FontSize', 15)

ylabel('Amplitude of Kuramoto-Sivashinky wave', 'fontsize', 14)
yt = get(gca, 'YTick');
set(gca, 'FontSize', 16)
axis([0 s1 ymin ymax])

hold on;
subplot(2,2,2);
plot(i_lam, 'k -.');
title({'Laminarity of normalized data', ''})
xlabel('Time instance', 'fontsize', 14)
xt = get(gca, 'XTick');
set(gca, 'FontSize', 15)
ylabel('Laminarity', 'fontsize', 14)
yt = get(gca, 'YTick');
set(gca, 'FontSize', 16)
hold on;
x1=1;
x2=max_index;
y1=1.0;
plot([x1, x2], [y1, y1], 'r')
y2=0.98;
plot([x1, x2], [y2, y2], 'r')
axis([0 s1 0 1])

subplot(2,2,3);
plot(rqa_data(:,9), 'k -.');
title({'Type-I recurrence', ''})
xlabel('Time instance', 'fontsize', 14)
xt = get(gca, 'XTick');
set(gca, 'FontSize', 15)
ylabel('Value', 'fontsize', 14)
yt = get(gca, 'YTick');
set(gca, 'FontSize', 16)
hold on;
x1=1;
x2=max_index;
y1=max(rqa_data(:,9)) - 0.45*max(rqa_data(:,9));
plot([x1, x2], [y1, y1], 'r')
y2=max(rqa_data(:,9)) + 0.05*max(rqa_data(:,9));
plot([x1, x2], [y2, y2], 'r')
axis([0 s1 0 y2])


subplot(2,2,4);
plot(rqa_data(:,10), 'k -.');
title({'Type-II recurrence', ''})
xlabel('Time instance', 'fontsize', 14)
xt = get(gca, 'XTick');
set(gca, 'FontSize', 15)
ylabel('Value', 'fontsize', 14)
yt = get(gca, 'YTick');
set(gca, 'FontSize', 16)
hold on;
x1=1;
x2=max_index;
y1=max(rqa_data(:,10)) - 0.45*max(rqa_data(:,10));
plot([x1, x2], [y1, y1], 'r')
y2=max(rqa_data(:,10)) + 0.05*max(rqa_data(:,10));
plot([x1, x2], [y2, y2], 'r')
axis([0 s1 0 y2])