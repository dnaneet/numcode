clc;
clear all;
close all;
%%

% index=dji102008102009; %epsilon=0.2
% index=nasdaq102008102009(75:125); 
% index=kcmx(190:569);
% index=h2016(1000:1600,9); %epsilon=0.25-0.3
%  index=aig(75:250,1); %epsilon=0.2
% index = bd(400:550,1);
%close all;
%index = h2016(2600:3200,9);
index = ksatx0;
[max_index, dont_need_this]=size(index)
index=index(1:max_index);
index_normalized= index/max(index);
figure;
plot(index_normalized, 'k -');

ymax=max(index_normalized); %For Y range in plots
ymin=-ymax; %For Y range in plots
%% Denoising.  Run this cell only if denoising data.
[thr,sorh,keepapp] = ddencmp('den','wv',index_normalized);
index_normalized_denoised = wdencmp('gbl',index_normalized,'db3',3,thr,sorh,keepapp);

figure;
subplot(211)
plot(index_normalized, 'k -+'); title('Original Signal');
xlabel('Time instance', 'fontsize', 14)
xt = get(gca, 'XTick');
set(gca, 'FontSize', 15)

ylabel('Normalized FPU Energy', 'fontsize', 14)
yt = get(gca, 'YTick');
set(gca, 'FontSize', 15)
axis([0 max_index ymin ymax])

subplot(212)
plot(index_normalized_denoised, 'k -+'); title('Denoised Signal');
xlabel('Time instance', 'fontsize', 14)
xt = get(gca, 'XTick');
set(gca, 'FontSize', 15)

ylabel('Normalized FPU Energy', 'fontsize', 14)
yt = get(gca, 'YTick');
set(gca, 'FontSize', 15)
axis([0 max_index ymin ymax])
%% Moving average filter
% windowSize = 5;
% b = (1/windowSize)*ones(1,windowSize);
% a = 1;
%  
% x=index_normalized_denoised;
% x=index_normalized;
% index_filtered=filter(b, a, x);
% 
% figure;
% subplot(211)
% plot(index_normalized); title('Original Signal');
% subplot(212)
% plot(index_normalized_denoised); title('M-A Denoised Signal')
%% RQA is performed in this cell

%data=index_normalized_denoised(1:max_index,1); %Uncomment this only if
%denoising has been performed,
data=index_normalized(1:max_index,1);
% data=index_filtered;
rqa_data=crqa(data, 1, 1, .2, 80, 1, 'euc', 'silent');
%%
%If RQA data is available, just run this cell alone.
[s1,s2] = size(data);
[s3,s4] = size(rqa_data(:,6));
padding_array=zeros(s1-s3,1);
i_lam = vertcat(padding_array, rqa_data(:,6));

%data
subplot(2,2,1);
plot(data, 'k -');
axis([0 max_index ymin ymax])
title('Normalized data')
xlabel('Time instance', 'fontsize', 14)
xt = get(gca, 'XTick');
set(gca, 'FontSize', 15)

ylabel('Amplitude of Kuramoto-Sivashinky wave', 'fontsize', 14)
yt = get(gca, 'YTick');
set(gca, 'FontSize', 16)
axis([0 s1 ymin ymax])

% laminarity
hold on;
subplot(2,2,2);
plot(i_lam, 'k -.');
title({'Laminarity of normalized data', ''})
xlabel('Time instance', 'fontsize', 14)
xt = get(gca, 'XTick');
set(gca, 'FontSize', 15)
ylabel('Laminarity', 'fontsize', 14)
yt = get(gca, 'YTick');
set(gca, 'FontSize', 16)
hold on;
x1=1;
x2=max_index;
y1=max(rqa_data(:,6)) - 0.1*max(rqa_data(:,6));
plot([x1, x2], [y1, y1], 'r')
y2=max(rqa_data(:,6)) - 0.02*max(rqa_data(:,6));
plot([x1, x2], [y2, y2], 'r')
axis([0 s1 0 1])

%type-2 recurrence

subplot(2,2,3);
plot(rqa_data(:,9), 'k -.');
title({'Type-I recurrence', ''})
xlabel('Time instance', 'fontsize', 14)
xt = get(gca, 'XTick');
set(gca, 'FontSize', 15)
ylabel('Value', 'fontsize', 14)
yt = get(gca, 'YTick');
set(gca, 'FontSize', 16)
hold on;
x1=1;
x2=max_index;
y1=max(rqa_data(:,9)) - 0.45*max(rqa_data(:,9));
plot([x1, x2], [y1, y1], 'r')
y2=max(rqa_data(:,9)) + 0.05*max(rqa_data(:,9));
plot([x1, x2], [y2, y2], 'r')
axis([0 s1 0 y2])

% trapping time
subplot(2,2,4);
plot(rqa_data(:,7), 'k -.');
title({'Trapping time', ''})
xlabel('Time instance', 'fontsize', 14)
xt = get(gca, 'XTick');
set(gca, 'FontSize', 15)
ylabel('Value', 'fontsize', 14)
yt = get(gca, 'YTick');
set(gca, 'FontSize', 16)
hold on;
x1=1;
x2=max_index;
y1=max(rqa_data(:,7)) - 0.45*max(rqa_data(:,7));
plot([x1, x2], [y1, y1], 'r')
y2=max(rqa_data(:,7)) + 0.05*max(rqa_data(:,7));
plot([x1, x2], [y2, y2], 'r')
axis([0 s1 0 y2])



%% Describing band of "relaxed" operation
plot(i_lam, 'k --^');
title({'Laminarity of De-noised DJI', 'between 10-2008 and 10-2009'})
hold on;
x1=1;
x2=253;
y1=0.98;
plot([x1, x2], [y1, y1])
y2=0.9;
plot([x1, x2], [y2, y2])