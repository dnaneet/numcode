clear rqa_data;
for i=1:1:51
    rqa_data{i}=crqa(ks(i,:), 1, 1, .2, 201, 1, 'euc', 'silent'); 
end
%% 
hold on;
for j=1:1:13    
    subplot(2,7,j)
    for i=1:1:51
        plot(rqa_data{i}(j), 'k*')
        hold on
    end
end

%%
for j=1:1:13    
    subplot(2,7,j)
    for i=1:10:50
      plot(rqa_data{i}(j), 'k*') 
      hold on;
      plot(rqa_data{i}(j), 'b^') 
    end
end

%% 
for j=1:1:13
subplot(2,7,j)    
plot(rqa_data{10}(j), 'k*') 
hold on;
plot(rqa_data{20}(j), 'k*') 
plot(rqa_data{30}(j), 'k*') 
plot(rqa_data{40}(j), 'k*') 
plot(rqa_data{50}(j), 'k*') 
end

%%

crp(ks(30,:))
